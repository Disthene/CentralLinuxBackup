# Application is stored in /etc/backup
#import modules
import os
import datetime
import shutil
import socket
from crontab import CronTab
#declare variables
svcaccount = 'user'                                                             #svc account on central and remote server
password = 'pfsense'                                                            #svc password for previous account
date = datetime.datetime.now().strftime('%d-%m-%Y_%H%M%S')                      #format the current dat in a variable
pathserversbackup = "/etc/backup/ServersBackup"                                 #define where the backup will be stored
pathserversbackup_old = "/etc/backup/ServersBackup_old"                         #define where removed backup will be stored
pathlogfile = "/etc/backup/log"+"/"+ "backup"+date                              #path of the logfile
pathconfigfile = "/etc/backup/config.txt"                                       #path of the current configuration file
exit = 0                                                                        #this is variable is used to exit the tool

#Create log file
logfile = open(pathlogfile,"a+")                                                #create logfile
logfile.write(date+"\r\n")                                                      #write the current date in the log file
#while exit=0 ask create, delete, check or exit
while exit == 0:                                                                #loop on the prompt until user press q
    inputdo = input("New Backup (n), Delete Backup (d), Check(c), exit(q): ")   #prompt to choose what to do
#---Create a new backup
    if inputdo == "n" or inputdo == "New" or inputdo == "new":                  #if the user chose to create a backup 
        inputname = input("Enter the name of the server: ")                     #variable for the server name
        inputpath = input("Enter the path of the folder: ")                     #variable for the folder to backup
        inputtime = input("Process backup every X hours(24 for 24 hours): ")    #variable for schedule backup time
        try: 
            socket.gethostbyname(inputname)                                     #check if the server exists
            pathserverbackup = pathserversbackup+"/"+inputname                  #path for the server backup folder
            pathscriptbackup = pathserverbackup+"/"+inputname+date+".py"        # path for the server backup script                       
            if not os.path.exists(pathserverbackup):                            #check if the folder already exist
                os.makedirs(pathserverbackup)                                   #otherwise we create it
            #add the config
            configfile = open(pathconfigfile,"a+")                              #open the config file to edit it
            configfile.write(inputname+" "+inputpath+" "+inputtime+";\r\n")     #add the new backup to the config file
            configfile.close()                                                  #close the config file
            #log the creation
            logfile.write("New folder"+inputpath+" has been created on "+inputname+" and planned every"+inputtime+" hours\r\n")
            #create script schedule backup
            remote = svcaccount+"@"+inputname                                   #format for the ssh command
            scriptfile = open(pathscriptbackup,"a+")                            #create the script for remote backup
            scriptfile.write("import subprocess"+"\r\n")                    
            scriptfile.write("import os"+"\r\n")
            scriptfile.write("import datetime"+"\r\n")
            scriptfile.write("date = "+"datetime.datetime.now().strftime('%d-%m-%Y_%H%M%S')"+"\r\n")
            scriptfile.write("remote = "+"'"+remote+"'"+"\r\n")
            scriptfile.write("password = "+"'"+password+"'"+"\r\n")
            scriptfile.write("inputpath = "+"'"+inputpath+"'"+"\r\n")
            scriptfile.write("pathserverbackup = "+"'"+pathserverbackup+"/"+"'"+'+date'+"\r\n")
            scriptfile.write("os.makedirs(pathserverbackup)"+"\r\n")
            scriptfile.write("subprocess.call(['sshpass','-p',password,'scp','-pr',':'.join([remote,inputpath]),pathserverbackup], shell = False)")
            scriptfile.close()                                                  #close the script
            #Schedule the script created above
            mycron = CronTab(user=svcaccount)                                   #plan the backup on the svc account
            job = mycron.new(command='python3 '+pathscriptbackup, comment=inputname+inputpath) #create a new schedule task
            job.hour.every(inputtime)                                           #plan the backup every X hours
            mycron.write()                                                      #save
            print("Backup has been set correctly for "+inputname)               #print that everything was configured correctly
        except Exception as e:
            print("Server doesn't exist")                                       #in case there is an error server doesn't exist
            
#---Delete a backup
    if inputdo == "d" or inputdo == "Delete" or inputdo == "delete":            #if the user chose to delete a backup
        inputname = input("Enter the name of the server: ")                     #prompt the user to chose the backup to delete
        pathserverbackup = pathserversbackup + "/" + inputname                  #store the path of the backup in a variable
        if os.path.exists(pathserverbackup):                                    #if path exist then we'll delete it
            shutil.rmtree(pathserverbackup)                                     #we delete the foler
            #delete from the config
            configfile = open(pathconfigfile,"r+")                              #open the config file to read it
            content = open(pathconfigfile).read().splitlines()                  #split each line of the config file in a list
            configfile.close()                                                  #close the config file
            configfile = open(pathconfigfile,"w+")                              #open the config file to recreate it
            configfile.close()                                                  #close the config file
            configfile = open(pathconfigfile,"a+")                              #open the config file to add content
            for i in content:                                                   #for each line we had before
                if not i.lstrip().startswith(inputname):                        #if the line is not starting by the servername we chose
                    configfile.write(i+"\r\n")                                  #then we'll write the old config lines
            configfile.close()                                                  #close config file
            #log the delete
            logfile.write("A server has been deleted "+inputname+"\r\n")        #log the backup removing
            #delete from crontab
            mycron = CronTab(user=svcaccount)                                   #load current tasks planned on this user
            for job in mycron:                                                  #for each tasks planned
                if inputname in job.comment:                                    #we'll check if a tasks with the servername exists
                    mycron.remove(job)                                          #if yes then we delete this task   
                    mycron.write()                                              #save
        else:                                                                   #in case the user entered a servername not configured
            print("Server name doesn't exist")                                  #we notice him that he entered a wrong server name

#---Display current configuration
    if inputdo == "c" or inputdo == "Check" or inputdo == "check":              #if the user chose to display the current configuration
        configfile = open(pathconfigfile,"r+")                                  #open the config file
        content = open(pathconfigfile).read().splitlines()                      #store the content of this file in a variable
        for i in content:                                                       #for each line in the previous variable
            print(i)                                                            #print the line
            
#---Exit
    if inputdo == "q" or inputdo == "Exit" or inputdo == "exit":                #if the user chose to close the program
        exit = 1                                                                #define exit to 1 to not enter the loop anymore
logfile.close()                                                                 #close the logfile